package com.mycompany.co2e

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
