import '/flutter_flow/flutter_flow_util.dart';
import 'writing_indicator_widget.dart' show WritingIndicatorWidget;
import 'package:flutter/material.dart';

class WritingIndicatorModel extends FlutterFlowModel<WritingIndicatorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
