import '/flutter_flow/flutter_flow_util.dart';
import 'social_widget.dart' show SocialWidget;
import 'package:flutter/material.dart';

class SocialModel extends FlutterFlowModel<SocialWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
