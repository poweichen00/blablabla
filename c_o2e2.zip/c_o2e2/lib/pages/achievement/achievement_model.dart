import '/flutter_flow/flutter_flow_util.dart';
import 'achievement_widget.dart' show AchievementWidget;
import 'package:flutter/material.dart';

class AchievementModel extends FlutterFlowModel<AchievementWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
