import 'package:c_o2e/admin_home/admin_post_widget.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../helper/helper_methods.dart';
import 'dashboard_screen.dart';

class PostsScreen extends StatelessWidget {
  static const String id = "posts";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.post_add),
            SizedBox(width: 10),
            Text('貼文管理'),
          ],
        ),
        automaticallyImplyLeading: false,
      ),

        body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('User Posts').orderBy('TimeStamp', descending: true).snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('No posts available'));
          } else {
            return ListView(
              children: snapshot.data!.docs.map((doc) {
                final postData = doc.data() as Map<String, dynamic>;

                Timestamp timestamp = postData['TimeStamp'] as Timestamp;

                return Column(
                  children: [
                    AdminPostWidget(
                      message: postData['Message'] ?? '',
                      user: postData['UserEmail'] ?? '',
                      postId: doc.id,
                      time: postData['TimeStamp'] != null
                          ? formatDate(timestamp)
                          : '',
                      imageUrl: postData['ImageUrl'] ?? '',
                      onDeletePressed: () => deletePostAdmin(
                          context, doc.id, postData['ImageUrl']),
                    ),
                    const Divider(),
                  ],
                );
              }).toList(),
            );
          }
        },
      ),
    );
  }

  void deletePostAdmin(
      BuildContext context, String postId, String? imageUrl) async {
    try {
      if (imageUrl != null && imageUrl.isNotEmpty) {
        Reference storageRef = FirebaseStorage.instance.refFromURL(imageUrl);
        await storageRef.delete();
      }

      // Delete comments associated with the post
      final commentDocs = await FirebaseFirestore.instance
          .collection("User Posts")
          .doc(postId)
          .collection("Comments")
          .get();

      for (var doc in commentDocs.docs) {
        await FirebaseFirestore.instance
            .collection("User Posts")
            .doc(postId)
            .collection("Comments")
            .doc(doc.id)
            .delete();
      }

      // Delete the post itself
      await FirebaseFirestore.instance
          .collection("User Posts")
          .doc(postId)
          .delete();

      print("貼文已刪除");
    } catch (error) {
      print("刪除貼文失敗: $error");
    }
  }
}
