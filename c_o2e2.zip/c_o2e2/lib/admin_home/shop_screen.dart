import 'package:flutter/material.dart';

class ShopScreen extends StatelessWidget {
  const ShopScreen({super.key});
  static const String id="shop";

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text(
            "Shop"
        ),
      ),
    );
  }
}
